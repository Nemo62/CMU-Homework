######################################################################################################################################
# Created by: Nehemiah Schaier
# Creation Date: 12/12/2021
# Last Modified: 12/12/2021
# 
# Description:
#
# This script/bot monitors a specicied cryptocurrency price. The monitored coin can be changed  on line 49 by the user. The script is 
# generic and should work with any of Coinbase Pro (CBpro) API compatible coins. CBpro is only accessing the public client and 
# does not require API credentials to use.
# 
# Prices are monitored in an infinite-while-loop every 10 seconds with the price staus being printed to the terminal for the user 
# to look through. In-Addtion to this significant, changes will be texted to the users cell phone through the Twilio API.
#
# The Twilio API will require an account with credentials to use. Visit https://www.twilio.com/ to create an account.
######################################################################################################################################

# /usr/bin/env python
import os
import cbpro
import time
from twilio.rest import Client
from twilio.rest.api.v2010.account import message
from twilioKey import twilioID, twilioKey

account_sid = twilioID # Twilio API ID.
auth_token = twilioKey # Twilio API KEY.

client = Client(account_sid, auth_token) # Login into Twilio.

public_client = cbpro.PublicClient() # Access the public CBpro API. No credentials required.

# Variable "start_Coin_Price" is used to get and hold a specified cryptocurrencies price to be compared against
# by a another variable holding the fluctuating price of this coin. Also reffered to as "start" or "base" price.
#
# Cryptocurrency is specified here in single quotation marks.
start_Coin_Price = public_client.get_product_ticker('SHIB-USD') #coin_name-currency Ex. "ADA-USD".

# Bool variable that is used in while loop.
flag = False

# Indefinite while loop that will monitor the specified cryptocurreny price fluctuations 
# and notify the user via text message if a big enough change occurs. Changes looked for are increases and decreases.
# 
# To terminate loop enter "ctrl + c".  
while True:

    # Variable "Track_Coin_Price" will update to the current price of the specified coin each iteration of the while loop. 
    track_Coin_Price = public_client.get_product_ticker('SHIB-USD') #coin_name-currency Ex. "ADA-USD".

    ######################################################################################################################################
    # Commented out code is for testing coin values to confirm that they are changing and interacting with CBpro.
    #print('Start Price: ', float(start_Coin_Price['price']))
    #print('Tracked Price: ', float(track_Coin_Price['price']))

    # Commented out code is for verifying that Twilio is sending text messages.
    #client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="TEST")
    #client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="Start Price: " + str(start_Coin_Price['price']))
    ######################################################################################################################################

    # variables that track price increases.
    price_increase_10 = (float(track_Coin_Price['price']) * .1) + float(start_Coin_Price['price'])
    price_increase_30 = (float(track_Coin_Price['price'])* .3) + float(start_Coin_Price['price'])
    price_increase_50 = (float(track_Coin_Price['price']) * .5) + float(start_Coin_Price['price'])

    # variables that track price decreases.
    price_decrease_5 = (float(track_Coin_Price['price']) * .05) - float(start_Coin_Price['price'])
    price_decrease_10 = (float(track_Coin_Price['price']) * .1) - float(start_Coin_Price['price'])
    price_decrease_15 = (float(track_Coin_Price['price']) * .15) - float(start_Coin_Price['price'])
    price_decrease_20 = (float(track_Coin_Price['price']) * .2) - float(start_Coin_Price['price'])
    price_decrease_25 = (float(track_Coin_Price['price']) * .25) - float(start_Coin_Price['price'])
    price_decrease_30 = (float(track_Coin_Price['price']) * .3) - float(start_Coin_Price['price'])

    # Checks for increases and either makes note of a minor change that is not text not text message worthy and prints to the terminal,
    # or discovers a text message worthy price change, sends a text and still prints to the terminal.
    if float(track_Coin_Price['price']) > float(start_Coin_Price['price']):
        
        if float(track_Coin_Price['price']) < price_increase_10: # Minor change not worth being notified over.
            print('Price went up less than 10%')

        elif float(track_Coin_Price['price']) > price_increase_10 and float(track_Coin_Price['price']) < price_increase_30:
            client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="Price went up 10%")
            print('Price went up 10%')
            time.sleep(590) # 590 seconds + 10 seconds = 10 minute delay

        elif float(track_Coin_Price['price']) > price_increase_30 and float(track_Coin_Price['price']) < price_increase_50:
            client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="Price went up 30%")
            print('Price went up 30%')
            time.sleep(590) # 590 seconds + 10 seconds = 10 minute delay

        elif float(track_Coin_Price['price']) > price_increase_50:
            client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="Price went up 50%")
            print('Price went up 50%')
            flag = True
    
    # Checks for decreases and either makes note of a minor change that is not text not text message worthy and prints to the terminal,
    # or discovers a text message worthy price change, sends a text and still prints to the terminal.
    elif float(track_Coin_Price['price']) < float(start_Coin_Price['price']):
        
        if float(track_Coin_Price['price']) > price_decrease_5 and float(track_Coin_Price['price']) < float(start_Coin_Price['price']): # Minor change not worth being notified over.
            print('Price dropped less than 5%')

        elif float(track_Coin_Price['price']) < price_decrease_5 and float(track_Coin_Price['price']) > price_decrease_10:
            client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="Price dropped 5%")
            print('Price dropped 5%')
            time.sleep(170) # 170 seconds + 10 seconds = 3 minute delay

        elif float(track_Coin_Price['price']) < price_decrease_10 and float(track_Coin_Price['price']) > price_decrease_15:
            client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="Price dropped 10%")
            print('Price dropped 10%')
            time.sleep(170) # 170 seconds + 10 seconds = 3 minute delay

        elif float(track_Coin_Price['price']) < price_decrease_15 and float(track_Coin_Price['price']) > price_decrease_20:
            client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="Price dropped 15%")
            print('Price dropped 15%')
            time.sleep(170) # 170 seconds + 10 seconds = 3 minute delay

        elif float(track_Coin_Price['price']) < price_decrease_20 and float(track_Coin_Price['price']) > price_decrease_25:
            client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="Price dropped 20%")
            print('Price dropped 20%')
            time.sleep(170) # 170 seconds + 10 seconds = 3 minute delay

        elif float(track_Coin_Price['price']) < price_decrease_25 and float(track_Coin_Price['price']) > price_decrease_30:
            client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="Price dropped 25%")
            print('Price dropped 25%')
            time.sleep(170) # 170 seconds + 10 seconds = 3 minute delay

        elif float(track_Coin_Price['price']) < price_decrease_30:
            client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="Price dropped 30%")
            print('Price dropped 30%')
            # A significant change has occurred setting the flag to true so we can access the if statement that updates the base coin price.
            flag = True
    
    # No change occured.
    else:
        print('No change in price.')

    # Significant change occured so we update our start/base price.
    if flag == True:
        
        # Base coin price made a significant increase.
        if float(track_Coin_Price['price']) > price_increase_50:
            client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="A significant increase has occurred. Check your CB.")
            start_Coin_Price = track_Coin_Price
            flag = False # Resets flag for future price changes.

        # Base coin price made a significant decrease.
        elif float(track_Coin_Price['price']) < price_increase_30:
            client.api.account.messages.create(to="+17204152428", from_="+17404802618", body="A significant decrease has occurred. Check your CB.")
            start_Coin_Price = track_Coin_Price
            flag = False # Resets flag for future price changes.

    # Pauses while loop for 10 seconds.
    time.sleep(10)